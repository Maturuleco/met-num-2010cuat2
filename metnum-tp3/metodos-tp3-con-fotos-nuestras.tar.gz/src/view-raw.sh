
display -size $2 -density 95 -depth 8 $1
